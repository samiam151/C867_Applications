#pragma once
#include <iostream>
using namespace std;

enum DEGREES {
	SECURITY,
	NETWORK,
	SOFTWARE
};

const string DEGREE_STRINGS[] = {
	"SECURITY",
	"NETWORK",
	"SOFTWARE"
};